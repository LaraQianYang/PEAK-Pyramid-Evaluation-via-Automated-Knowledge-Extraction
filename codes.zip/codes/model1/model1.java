package model1;

import java.io.IOException;

public class model1 {

	public static void main(String args[]) throws IOException {
	  
	  step1.step1();
	  step2.step2();
	  step3.step3();
	  step4.step4();
	  step5.step5();
	  step6.step6();
	  step7.step7();
	  step8.step8();
	  step9.step9();
	  step10.step10();
	  step11.step11();
	  
	}
	
}
