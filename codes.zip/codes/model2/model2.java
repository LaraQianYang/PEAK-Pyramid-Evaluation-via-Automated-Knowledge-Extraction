package model2;

import java.io.IOException;


public class model2 {
	public static void main(String args[]) throws IOException {
		  
		  step12.step12();
		  step13.step13();
		  step14.step14();
	}
}
