package model3;

import java.io.IOException;

import model1.step1;
import model1.step10;
import model1.step11;
import model1.step2;
import model1.step3;
import model1.step4;
import model1.step5;
import model1.step6;
import model1.step7;
import model1.step8;
import model1.step9;
import model2.step12;
import model2.step13;
import model2.step14;

public class model3 {
	public static void main(String args[]) throws IOException {
		
		step1.step1();
		step2.step2();
		step3.step3();
		step4.step4();
		step5.step5();
		step6.step6();
		step7.step7();
		step8.step8();
		step9.step9();
		step10.step10();
		step11.step11();
		step12.step12();
		step13.step13();
		step14.step14();
	}
}
